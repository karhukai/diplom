﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace metr
{
    public class TableNode
    {
        public string Name { get; set; }
        public List<TableNode> Children { get; set; } = new List<TableNode>();
    }
}