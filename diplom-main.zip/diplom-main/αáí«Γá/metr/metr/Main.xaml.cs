﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Collections;

namespace metr
{
    public partial class Main : Window
    {
        public Main()
        {
            InitializeComponent();

            // Инициализация дерева таблиц
            DataContext = this;
            Tables = new System.Collections.ObjectModel.ObservableCollection<TableNode>(Helper.GetTables());

            // Подписка на событие выбора таблицы
            DatabaseTree.SelectedItemChanged += DatabaseTree_SelectedItemChanged;
        }

        public System.Collections.ObjectModel.ObservableCollection<TableNode> Tables { get; set; }

        private void DatabaseTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            var selectedNode = DatabaseTree.SelectedItem as TableNode;
            if (selectedNode != null)
            {
                var context = Helper.GetContext();
                var tableProperty = context.GetType().GetProperty(selectedNode.Name);

                if (tableProperty != null)
                {
                    try
                    {
                        // Получаем DbSet<TEntity>
                        var dbSet = tableProperty.GetValue(context) as dynamic;

                        if (dbSet != null)
                        {
                            // Преобразуем в IEnumerable и вызываем ToList()
                            var result = ((System.Collections.IEnumerable)dbSet).Cast<object>().ToList();

                            // Отображаем в DataGrid
                            DataGrid.ItemsSource = result;
                            StatusMessage.Text = $"Загружено: {selectedNode.Name}";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
                    }
                }
            }
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            var selectedNode = DatabaseTree.SelectedItem as TableNode;
            if (selectedNode != null)
            {
                var context = Helper.GetContext();
                var tableProperty = context.GetType().GetProperty(selectedNode.Name);

                if (tableProperty != null)
                {
                    try
                    {
                        // Получаем DbSet<TEntity>
                        var dbSet = tableProperty.GetValue(context) as dynamic;

                        if (dbSet != null)
                        {
                            // Материализуем данные через ToList()
                            var result = ((System.Collections.IEnumerable)dbSet).Cast<object>().ToList();

                            // Отображаем в DataGrid
                            DataGrid.ItemsSource = result;
                            StatusMessage.Text = $"Обновлено: {selectedNode.Name}";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
                    }
                }
            }
        }
        // context.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);
        private void Save_Click(object sender, RoutedEventArgs e)
        {
            var selectedNode = DatabaseTree.SelectedItem as TableNode;
            if (selectedNode == null)
            {
                MessageBox.Show("Выберите таблицу в левом дереве.");
                return;
            }

            var context = Helper.GetContext();
            var tableProperty = context.GetType().GetProperty(selectedNode.Name);

            if (tableProperty == null)
            {
                MessageBox.Show($"Таблица {selectedNode.Name} не найдена в контексте.");
                return;
            }

            try
            {
                var dbSet = tableProperty.GetValue(context) as dynamic;
                var entityType = tableProperty.PropertyType.GenericTypeArguments[0];
                var items = DataGrid.ItemsSource as System.Collections.IList;

                if (items == null || items.Count == 0)
                {
                    MessageBox.Show("Нет данных для сохранения.");
                    return;
                }

                foreach (var item in items)
                {
                    if (item.GetType() != entityType)
                        continue;

                    var idProperty = entityType.GetProperty("ID");
                    if (idProperty == null)
                        continue;

                    var idValue = idProperty.GetValue(item);
                    if (idValue is int && (int)idValue == 0)
                        continue; // Пропускаем новые записи

                    // Прикрепляем и обновляем существующие
                    dbSet.Attach(item);
                    context.Entry(item).State = EntityState.Modified;
                }

                context.SaveChanges();
                StatusMessage.Text = "Изменения сохранены.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}");
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var selectedItem = DataGrid.SelectedItem;
            if (selectedItem != null)
            {
                var context = Helper.GetContext();
                context.Entry(selectedItem).State = EntityState.Deleted;
                context.SaveChanges();
                Refresh_Click(sender, e);
                StatusMessage.Text = "Запись удалена.";
            }
        }

        private void ConnectToDatabase_Click(object sender, RoutedEventArgs e)
        {
            // Реализуйте подключение к БД, если требуется
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void NewQuery_Click(object sender, RoutedEventArgs e)
        {
            var selectedNode = DatabaseTree.SelectedItem as TableNode;
            if (selectedNode == null)
            {
                MessageBox.Show("Выберите таблицу в левом дереве.");
                return;
            }

            var context = Helper.GetContext();
            var tableProperty = context.GetType().GetProperty(selectedNode.Name);

            if (tableProperty == null)
            {
                MessageBox.Show($"Таблица {selectedNode.Name} не найдена в контексте.");
                return;
            }

            try
            {
                // Получаем DbSet<TEntity>
                var dbSet = tableProperty.GetValue(context) as dynamic;

                if (dbSet == null)
                {
                    MessageBox.Show("Не удалось получить DbSet.");
                    return;
                }

                // Получаем тип сущности
                var entityType = tableProperty.PropertyType.GenericTypeArguments[0];

                // Создаем новый объект через рефлексию
                var newItem = Activator.CreateInstance(entityType);

                // Добавляем в DbSet
                dbSet.Add(newItem);

                // Сохраняем изменения
                context.SaveChanges();

                // Обновляем DataGrid
                var result = ((System.Collections.IEnumerable)dbSet).Cast<object>().ToList();
                DataGrid.ItemsSource = result;

                StatusMessage.Text = "Новая запись добавлена.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении записи: {ex.Message}");
            }
        }
        //fdfd
    }
}