﻿using metr;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Reflection;

public class Helper
{
    public static metrologyEntities GetContext()
    {
        return new metrologyEntities();
    }

    public static List<TableNode> GetTables()
    {
        var context = GetContext();
        var tables = new List<TableNode>();

        foreach (var property in context.GetType().GetProperties())
        {
            if (property.PropertyType.IsGenericType &&
                property.PropertyType.GetGenericTypeDefinition() == typeof(DbSet<>))
            {
                tables.Add(new TableNode { Name = property.Name });
            }
        }

        return tables;
    }

    public static METROLOGY_USER User;
}